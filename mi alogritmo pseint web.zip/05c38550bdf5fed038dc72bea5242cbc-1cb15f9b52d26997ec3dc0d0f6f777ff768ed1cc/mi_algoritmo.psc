Algoritmo ControlEstacionamiento
    // variabels tipos
    Definir matricula Como Caracter
    Definir registrado Como Logico
    Definir espaciosDisponibles Como Entero
    Definir continuar Como Logico
    
    // variables
    espaciosDisponibles <- 10
    continuar <- Verdadero
    
    // Menú principal
    Mientras continuar Hacer
        Escribir "   SISTEMA DE ESTACIONAMIENTO"
        Escribir "Espacios disponibles: ", espaciosDisponibles
        Escribir ""
        Escribir "1. Ingresar vehículo"
        Escribir "2. Salir del sistema"
        Escribir "Seleccione una opción: "
        Leer opcion
        
        Segun opcion Hacer
            1:
                
                Escribir "Ingrese la matrícula del vehículo: "
                Leer matricula
                
                
                Si matricula = "20263213DD32" Entonces
                    registrado <- Verdadero
                Sino
                    registrado <- Falso
                FinSi
                
                // Decisión 1: ¿Está registrado?
                Si registrado = Verdadero Entonces
                    // Decisión 2: ¿Hay espacios disponibles?
                    Si espaciosDisponibles > 0 Entonces
                        // Permitir entrada
                        espaciosDisponibles <- espaciosDisponibles - 1
                        Escribir "Bienvenido. Ingrese al estacionamiento"
                        Escribir "Espacios restantes: ", espaciosDisponibles
                    Sino
                        Escribir "ESTACIONAMIENTO LLENO. No hay lugares disponibles"
                    FinSi
                Sino
                    Escribir "ACCESO DENEGADO. Usuario no registrado"
                FinSi
                
            2:
                continuar <- Falso
                Escribir "Saliendo del sistema..."
                
            De Otro Modo:
                Escribir "Opción inválida. Intente nuevamente."
        FinSegun
        
        Escribir ""
    FinMientras
    
    Escribir "¡Hasta luego!"
FinAlgoritmo